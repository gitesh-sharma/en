TITLE: en Template - 100% Fully Responsive Template

AUTHOR:
DESIGNED & DEVELOPED by Gitesh Sharma.

Website: http://giteshgeeky.blogspot.com
Twitter: http://twitter.com/giteshsharma_
Facebook: http://facebook.com/giteshsharma.gs
Instagram: http://instagram.com/giteshsharma_
YouTube: http://youtube.com/c/giteshgeeky


CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/

Modernizr
http://modernizr.com/

Google Fonts
https://www.google.com/fonts/

Icomoon
https://icomoon.io/app/

Respond JS
https://github.com/scottjehl/Respond/blob/master/LICENSE-MIT

animate.css
http://daneden.me/animate

jQuery Waypoint
https://github.com/imakewebthings/waypoints/blog/master/licenses.txt

Easy Pie Chart
https://github.com/rendro/easy-pie-chart
